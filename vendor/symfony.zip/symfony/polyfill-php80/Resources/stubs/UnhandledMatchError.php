<?php

class UnhandledMatchError extends Error
{
}
